package com.App.AlCastleCS360Project3;

/* Public class to get Inventory Users */
public class Inventory_Users {
    private String Username;
    private String Password;

    public Inventory_Users(){}

    public Inventory_Users(String username, String password) {
        super();
        this.Username = username;
        this.Password = password;

    }

    // gets username
    public String getUserName() {

        return Username;

    }

    // get the password
    public String getPassword() {

        return Password;

    }

    // sets the username
    public void setUserName(String username) {

        this.Username = username;

    }

    // set the password
    public void setPassword(String password) {

        this.Password = password;

    }

}
